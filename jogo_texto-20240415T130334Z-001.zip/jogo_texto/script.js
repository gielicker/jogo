function limpatela(){
    corpo.innerHTML = "";

    story.innerHTML = '<h2 id="story">teste </h2>'



}